# CodeRocket Universal Tools

This repository contains helper scripts for layman users to:
✅ Automate GitHub updates (push/pull)
✅ Get laptop popups for API usage warnings
✅ Send email alerts
✅ Create standard project folders automatically
✅ Combine update, push, and app launch in one script

Created for Captain Anil (powerpbox@gmail.com).
